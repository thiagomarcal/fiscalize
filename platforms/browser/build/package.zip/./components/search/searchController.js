myApp.controller('SearchController', function($scope, $timeout , $http, $location, $stateParams, requisicaoFactory)  {

	

});
	